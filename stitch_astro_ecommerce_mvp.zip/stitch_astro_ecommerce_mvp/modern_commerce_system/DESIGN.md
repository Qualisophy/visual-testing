---
name: Modern Commerce System
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#42474f'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#727780'
  outline-variant: '#c1c7d1'
  surface-tint: '#286196'
  primary: '#286196'
  on-primary: '#ffffff'
  primary-container: '#6296ce'
  on-primary-container: '#002d4f'
  inverse-primary: '#9dcaff'
  secondary: '#555d7e'
  on-secondary: '#ffffff'
  secondary-container: '#d1d8ff'
  on-secondary-container: '#565e7f'
  tertiary: '#5b5f62'
  on-tertiary: '#ffffff'
  tertiary-container: '#8f9396'
  on-tertiary-container: '#282c2e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e4ff'
  primary-fixed-dim: '#9dcaff'
  on-primary-fixed: '#001d35'
  on-primary-fixed-variant: '#00497c'
  secondary-fixed: '#dce1ff'
  secondary-fixed-dim: '#bdc5eb'
  on-secondary-fixed: '#111a37'
  on-secondary-fixed-variant: '#3d4565'
  tertiary-fixed: '#e0e3e6'
  tertiary-fixed-dim: '#c3c7ca'
  on-tertiary-fixed: '#181c1e'
  on-tertiary-fixed-variant: '#43474a'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
---

## Brand & Style
The design system is engineered for a high-end, reliable e-commerce experience. It prioritizes clarity, trust, and effortless navigation. The aesthetic leans into **Corporate Modernism**—characterized by generous whitespace, a structured grid, and a sophisticated color palette that balances technical precision with approachable utility. 

The emotional response should be one of confidence and efficiency. We avoid unnecessary decorative elements, instead letting high-quality product photography and crisp typography drive the visual narrative. The interface feels "quiet" but powerful, ensuring the user's path to purchase is free of friction.

## Colors
The palette is anchored by a professional blue duo. The **Primary Blue (#6296CE)** is used for key actions, focus states, and highlighting active selections. The **Secondary Dark Blue (#1B2341)** provides grounding contrast, used primarily for navigation backgrounds, footers, and primary headings to establish a sense of authority.

We utilize a range of neutrals to manage hierarchy. Backgrounds should primarily be white (#FFFFFF) or the Tertiary light blue-gray (#F4F7FA) to define sections. Semantic colors (Success, Warning, Error) should follow standard accessibility conventions but be slightly desaturated to match the professional tone of the system.

## Typography
This design system utilizes **Inter** exclusively to maintain a clean, systematic appearance. The type scale is optimized for readability and clear information density. 

- **Headlines:** Use Semi-Bold (600) or Bold (700) weights with slight negative letter spacing for a compact, modern feel.
- **Body Text:** Standardize on Regular (400) for long-form content and Medium (500) for emphasized UI text.
- **Labels:** Use Medium or Semi-Bold at smaller sizes to ensure legibility in functional components like buttons and chips. 
- **Contrast:** Ensure all text passes WCAG AA standards against their respective backgrounds.

## Layout & Spacing
The design system employs a **12-column fluid grid** for desktop and a **4-column grid** for mobile. We use an 8px base unit for all spatial relationships.

- **Margins:** Desktop views should have a minimum side margin of 48px, while mobile uses a tight 16px margin to maximize screen real estate.
- **Gaps:** Maintain a consistent 24px gutter between grid items to ensure breathing room.
- **Vertical Rhythm:** Use the `lg` (48px) spacing unit to separate major page sections (e.g., Hero to Featured Products). Use `md` (24px) for spacing within components like cards.

## Elevation & Depth
Depth in this design system is achieved through **Tonal Layering** and **Soft Ambient Shadows**. We avoid heavy black shadows in favor of tinted, low-opacity shadows that feel integrated into the UI.

- **Level 0 (Flat):** Used for the main background surface.
- **Level 1 (Card):** Minimal depth. A subtle 1px border (#E2E8F0) and an extremely soft shadow (0px 2px 4px rgba(27, 35, 65, 0.04)).
- **Level 2 (Hover/Dropdown):** Moderate depth. Used for cards in an active state or small overlays. (0px 10px 15px rgba(27, 35, 65, 0.08)).
- **Level 3 (Modals):** High depth to pull the element forward. (0px 20px 25px rgba(27, 35, 65, 0.12)).

Surfaces should use subtle shifts in background color (e.g., white to #F4F7FA) to denote hierarchy before relying on shadows.

## Shapes
The shape language is **Rounded**, striking a balance between the clinical feel of sharp corners and the playfulness of pill shapes. 

- **Standard Elements:** Buttons, input fields, and small cards use a 0.5rem (8px) radius.
- **Large Containers:** Product cards and modals use a 1rem (16px) radius to feel more approachable.
- **Interactive Micro-elements:** Checkboxes use a smaller 4px radius, while radio buttons remain fully circular.

## Components

### Buttons
- **Primary:** Background #6296CE, Text #FFFFFF. 
    - *Hover:* Darken primary by 10%.
    - *Active:* Darken primary by 15%.
    - *Disabled:* Background #CBD5E1, Text #FFFFFF, Cursor not-allowed.
- **Secondary:** Transparent background, Border 1px #6296CE, Text #6296CE.
- **Sizes:** Small (32px height), Medium (44px height), Large (56px height).

### Form Inputs
- **Default State:** White background, 1px border #E2E8F0, 8px padding. 
- **Focus State:** Border #6296CE with a 2px outer glow of 20% opacity primary color.
- **Error State:** Border #EF4444. Error text displayed in 12px font below the field.

### Navigation Bar
- **Desktop:** Height 80px, Background #FFFFFF, Bottom border 1px #F1F5F9. Logo left, search center-weighted, utility (cart/profile) right.
- **Sticky:** Nav bar should fix to the top of the viewport on scroll with a Level 1 shadow.

### Product Cards
- **Structure:** Image container (top), padding 16px for content (bottom).
- **Hover:** Card lifts slightly (Level 2 shadow) and product title changes to Primary color.
- **Badges:** Small labels for "New" or "Sale" should be placed in the top-left of the image container with 4px radius.

### Chips & Tags
- Used for categories or filters. Light gray background (#F1F5F9) with Medium 500 weight text. 8px horizontal padding.